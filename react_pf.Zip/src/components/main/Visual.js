function Visual() {
	return <figure id='visual'>Visual</figure>;
}

export default Visual;
